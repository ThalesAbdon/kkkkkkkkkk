export interface DeleteOrderUsecaseInput {
  id: number;
}
