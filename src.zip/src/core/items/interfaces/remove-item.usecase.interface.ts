export interface RemoveItemUsecaseInput {
  id: number;
}
