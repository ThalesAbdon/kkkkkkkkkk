export interface DeleteProductUsecaseInput {
  id: number;
}
