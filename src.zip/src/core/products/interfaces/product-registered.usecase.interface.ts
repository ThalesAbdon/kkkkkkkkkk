export interface VerifyProductUsecaseInput {
  name: string;
}
