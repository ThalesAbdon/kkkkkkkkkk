export interface FindByIdProductUsecaseInput {
  id: number;
}
