export interface ActivedAccountUsecaseInput {
  id: number;
}
