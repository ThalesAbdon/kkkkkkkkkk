export interface FindByIdUserUsecaseInput {
  id: number;
}
