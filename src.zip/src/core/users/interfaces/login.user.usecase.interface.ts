export interface LoginUserUsecaseInput {
  email: string;
  password: string;
}
