export interface VerifyEmailInput {
  email: string;
}
