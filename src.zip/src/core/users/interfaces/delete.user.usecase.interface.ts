export interface DeleteUserUsecaseInput {
  id: number;
}
