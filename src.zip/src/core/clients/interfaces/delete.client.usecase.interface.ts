export interface DeleteClientUsecaseInput {
  id: number;
}
