export interface FindByIdClientUsecaseInput {
  id: number;
}
