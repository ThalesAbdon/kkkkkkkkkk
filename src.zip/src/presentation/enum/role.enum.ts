export enum Role {
  Client = 'client',
  Admin = 'admin',
}
