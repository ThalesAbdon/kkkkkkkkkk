export interface FindByIdOrderApplicationInput {
  id: number;
}
