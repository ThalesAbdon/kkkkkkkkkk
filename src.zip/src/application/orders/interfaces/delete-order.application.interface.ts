export interface DeleteOrderApplicationInput {
  id: number;
}
