export interface DeleteUserApplicationInput {
  id: number;
}
