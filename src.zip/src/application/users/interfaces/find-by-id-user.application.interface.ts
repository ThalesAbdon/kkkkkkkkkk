export interface FindByIdUserApplicationInput {
  id: number;
}
