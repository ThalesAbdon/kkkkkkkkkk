export interface ActivedAccountApplicationInput {
  id: string;
  token: string;
}
