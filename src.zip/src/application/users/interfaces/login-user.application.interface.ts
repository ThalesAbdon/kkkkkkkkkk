export interface LoginUserApplicationInput {
  email: string;
  password: string;
}
