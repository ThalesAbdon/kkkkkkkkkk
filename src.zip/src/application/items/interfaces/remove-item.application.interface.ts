export interface RemoveItemApplicationInput {
  id: number;
}

export interface RemoveItemApplicationOutput {
  message: string;
}
