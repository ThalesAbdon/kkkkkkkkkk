export interface FindByIdItemApplicationInput {
  id: number;
}
