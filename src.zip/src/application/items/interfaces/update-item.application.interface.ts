export interface UpdateItemApplicationInput {
  quantity: number;
}

export interface UpdateItemApplicationOutput {
  message: string;
}
