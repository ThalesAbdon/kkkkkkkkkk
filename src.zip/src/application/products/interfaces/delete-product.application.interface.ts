export interface DeleteProductApplicationInput {
  id: number;
}
