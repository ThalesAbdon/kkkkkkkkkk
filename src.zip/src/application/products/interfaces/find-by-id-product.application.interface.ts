export interface FindByIdProductApplicationInput {
  id: number;
}
