export interface DeleteClientApplicationInput {
  id: number;
}
