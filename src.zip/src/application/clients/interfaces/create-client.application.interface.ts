export interface CreateClientApplicationInput {
  fullName: string;
  contact: string;
  address: string;
}

export interface CreateClientApplicationOutput {
  message: string;
}
