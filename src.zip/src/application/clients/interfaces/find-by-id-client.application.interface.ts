export interface FindByIdClientApplicationInput {
  id: number;
}
