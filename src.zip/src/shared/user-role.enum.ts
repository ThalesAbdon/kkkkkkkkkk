export enum UserRole {
  ADMIN = 'admin',
  CLIENT = 'client',
}
